package com.edu.pnu.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.pnu.domain.MemberVO;
import com.edu.pnu.service.MemberService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor // final 선언한 변수 참조 자동 생성 --> lombok
@RestController
public class MemberController {
	
	private final MemberService sv;
	
//	public MemberController() {
//		System.out.println("생성");
//		sv = new MemberService();
//		sv.setMd(new MemberDao());
//	}
//	public MemberController(MemberService sv) {
//		System.out.println("생성");
//		this.sv = sv;
//		
//	}
	
	@GetMapping("/members")
	public List<MemberVO> getAllMember() {
		return sv.getAllMember();
	}
	
	@GetMapping("/member")
	public MemberVO getMemberById(Integer Id) {
		return sv.getMemberById(Id);
	}
	
	@PostMapping("/member")
	public MemberVO addMember(MemberVO memberVO) {
		return sv.addMember(memberVO);
	}
	
	@PutMapping("/member")
	public int updateMembers(MemberVO memberVO) {
		return sv.updateMembers(memberVO);
	}
	
	@DeleteMapping("/member")
	public int removeMember(Integer Id) {
		return sv.removeMember(Id);
	}
	
	@PostMapping("/memberJSON")
	public MemberVO addMemberJSON(@RequestBody MemberVO memberVO) {
		return sv.addMemberJSON(memberVO);
	}
}
