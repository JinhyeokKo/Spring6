package com.edu.pnu.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestBody;

import com.edu.pnu.domain.MemberVO;

import lombok.RequiredArgsConstructor;
@RequiredArgsConstructor
@Repository
public class MemberDao {
	
	private final DataSource ds;
	private ResultSet rs;
	private Statement st;
	private PreparedStatement psmt;
	
	public List<MemberVO> getAllMember(){
		List<MemberVO> list = new ArrayList<>();
		try {
			st = ds.getConnection().createStatement();
			rs = st.executeQuery("SELECT * FROM member");
			
			while(rs.next()) {
				MemberVO m = new MemberVO();
				m.setId(rs.getInt("ID"));
				m.setName(rs.getString("NAME"));
				m.setPass(rs.getString("PASS"));
				m.setRegidate(rs.getDate("REGIDATE"));
				list.add(m);
			}
		}catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(st!=null) st.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public MemberVO getMemberById(Integer Id) {
		MemberVO m = new MemberVO();
		try {
			psmt = ds.getConnection().prepareStatement("SELECT * FROM member WHERE ID=?");
			psmt.setInt(1, Id);
			rs = psmt.executeQuery();
			while(rs.next()) {
				m.setId(rs.getInt("ID"));
				m.setName(rs.getString("NAME"));
				m.setPass(rs.getString("PASS"));
				m.setRegidate(rs.getDate("REGIDATE"));
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(psmt!=null) psmt.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return m;
	}
	
	public MemberVO addMember(MemberVO memberVO) {
		try {
			if(getMemberById(memberVO.getId())!=null)
				return null;
			memberVO.setRegidate(new Date());
			memberVO.setName("name"+memberVO.getId());
			memberVO.setPass("pass"+memberVO.getId());
			psmt = ds.getConnection().prepareStatement("INSERT INTO member (ID,NAME,PASS) VALUES (?, ?, ?)");
			psmt.setInt(1, memberVO.getId());
			psmt.setString(2, memberVO.getName());
			psmt.setString(3, memberVO.getPass());
			psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try{
				if(psmt!=null) psmt.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return memberVO;
	}
	
	public int updateMembers(MemberVO memberVO) {
		try {
			if(getMemberById(memberVO.getId())==null) return 0;
			MemberVO m = new MemberVO();
			m.setName(memberVO.getName());
			m.setPass(memberVO.getPass());
			psmt = ds.getConnection().prepareStatement("UPDATE member SET NAME=?, PASS=? WHERE ID=?");
			psmt.setString(1, memberVO.getName());
			psmt.setString(2, memberVO.getPass());
			psmt.setInt(3, memberVO.getId());
			psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(psmt!=null) psmt.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return 1;
	}
	
	public int removeMember(Integer Id) {
		try {
			if(getMemberById(Id)==null) return 0;
			psmt = ds.getConnection().prepareStatement("DELETE FROM member WHERE ID=?");
			psmt.setInt(1, Id);
			psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(psmt!=null) psmt.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return 1;
	}
	
	public MemberVO addMemberJSON(@RequestBody MemberVO memberVO) {
		try {
			if(getMemberById(memberVO.getId())!=null) return null;
			memberVO.setRegidate(new Date());
			memberVO.setName("name"+memberVO.getId());
			memberVO.setPass("pass"+memberVO.getId());
			psmt = ds.getConnection().prepareStatement("INSERT INTO member (ID,NAME,PASS) VALUES (?, ?, ?)");
			psmt.setInt(1, memberVO.getId());
			psmt.setString(2, memberVO.getName());
			psmt.setString(3, memberVO.getPass());
			psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try{
				if(psmt!=null) psmt.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return memberVO;
	}
}
