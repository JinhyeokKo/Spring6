package com.nu;

import org.springframework.stereotype.Service;

@Service
public class test {
	public test() {
		System.out.println("sn");
	}
}