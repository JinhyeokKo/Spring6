package com.edu.pnu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.edu.pnu.dao.MemberDao;
import com.edu.pnu.domain.MemberVO;

@Service
public class MemberService {
	
	@Autowired
	private MemberDao md;
	
	public MemberService() {
		System.out.println("생성2");
	}
	
//	public MemberService() {
//		md = new MemberDao();
//	}
	
//	public void setMd(MemberDao md) {
//		this.md = md;
//	}

	public List<MemberVO> getAllMember(){
		return md.getAllMember();
	}
	
	public MemberVO getMemberById(Integer Id) {
		return md.getMemberById(Id);
	}
	
	public MemberVO addMember(MemberVO memberVO) {
		return md.addMember(memberVO);
	}
	
	public int updateMembers(MemberVO memberVO) {
		return md.updateMembers(memberVO);
	}
	
	public int removeMember(Integer Id) {
		return md.removeMember(Id);
	}
	
	public MemberVO addMemberJSON(@RequestBody MemberVO memberVO) {
		return md.addMemberJSON(memberVO);
	}
}
