package com.edu.pnu.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration // 이 클래스가 설정 클래스라고 정의(IoC 컨테이너에 로드)
@EnableWebSecurity // 스프링 시큐리티 적용에 필요한 필터 객체를 자동 생성
public class SecurityConfig {
	// securityfilterchain 객체를 생성해서 bean으로 등록하면 기본 로그인 화면이 나타나지 않음
	// 기본 로그인 화면을 사용하거나 사용자가 작성한 로그인 화면을 사용하겠다는 설정 필요
	@Bean // 이 메서드가 리턴하는 객체를 IoC 컨테이너에 등록하는 지시
	SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
		// 접근 권한 설정
		http.authorizeHttpRequests(security->security
				.requestMatchers("/member/**").authenticated()
				.requestMatchers("/manager/**").hasAnyRole("MANAGER", "ADMIN")
				.requestMatchers("/admin/**").hasRole("ADMIN")
				.anyRequest().permitAll());
		
		// CSRF 보호 비활성화(사이트간 요청 위조)
		http.csrf(cf->cf.disable());
		
		// 스프링부트가 제공해주는 로그인 사용하겠다는 설정
		http.formLogin(form->{});
		
		// true -> /member를 호출해서 로그인 화면으로 왔을 때 로그인 성공 시 /loginSuccess로 이동
		// false -> 그렇지 않고 로그인 성공 시 호출한 url인 /member로 이동
		http.formLogin(form->form.loginPage("/login").defaultSuccessUrl("/loginSuccess", true));
		
		// 접근 권한 없음 페이지 처리
		http.exceptionHandling(ex->ex.accessDeniedPage("/accessDenied"));
		
		// 로그아웃 처리
		http.logout(logout->logout
				.invalidateHttpSession(true) // 현재 브라우저와 연결된 세션 강제 종료
				.deleteCookies("JSESSIONID") // 세션 아이디가 저장된 쿠키 삭제
				.logoutSuccessUrl("/login")); // 로그아웃 후 이동할 URL 지정
		
		http.headers(hr->hr.frameOptions(fo->fo.disable()));
		
		return http.build();
	}
	
	@Autowired
	public void authenticate(AuthenticationManagerBuilder auth) throws Exception{
		// 임시 테스트용 메모리 사용자 등록
//		auth.inMemoryAuthentication()
//		.withUser("manager")
//		.password("{noop}1234") // {noop} : No Operation -> 비밀번호가 암호화되어 있지 않다는 의미
//		.roles("MANAGER");
//		auth.inMemoryAuthentication()
//		.withUser("admin")
//		.password("{noop}1234")
//		.roles("ADMIN");
	}
	
	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}
