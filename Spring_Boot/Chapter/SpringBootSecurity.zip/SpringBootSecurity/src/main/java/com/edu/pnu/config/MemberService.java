package com.edu.pnu.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.edu.pnu.domain.Member;
import com.edu.pnu.domain.Role;
import com.edu.pnu.persistence.MemberRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MemberService {
	@Autowired
	private final MemberRepository memberRepo;
	private final PasswordEncoder encoder;
	public void save(Member member) {
		memberRepo.save(Member.builder().username(member.getUsername()).password(encoder.encode(member.getPassword())).role(Role.ROLE_MEMBER).enabled(true).build());
	}
}
