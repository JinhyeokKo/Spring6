package com.edu.pnu.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.edu.pnu.domain.MemberVO;

public class MemberService {
	private List<MemberVO> list = new ArrayList<>();
	
	public MemberService() {
		for (int i = 0; i <=10; i++) {
			list.add(MemberVO.builder().id(i).pass("pass" + i).name("name" + i).regidate(new Date()).build());
		}
	}
	
	public List<MemberVO> getMembers() {
		return list;
	}
	
	public MemberVO getMemberById(Integer Id) {
		for(MemberVO m : list) {
			if(m.getId() == Id)
				return m;
		}
		return null;
	}
	
	public MemberVO addMember(MemberVO memberVO) {
		if(getMemberById(memberVO.getId()) !=null )
			return null;
		memberVO.setRegidate(new Date());
		list.add(memberVO);
		return memberVO;
	}
	
	public int updateMembers(MemberVO memberVO) {
		MemberVO m = getMemberById(memberVO.getId());
		if(m == null)
			return 0;
		m.setName(memberVO.getName());
		m.setPass(memberVO.getPass());
		return 1;
	}
	
	public int removeMember(Integer Id) {
		try {
			list.remove(getMemberById(Id));
		} catch(Exception e) {
			return 0;
		}
		return 1;
	}
	
	public MemberVO addMemberJSON(@RequestBody MemberVO memberVO) {
		if(getMemberById(memberVO.getId()) !=null)
			return null;
		memberVO.setRegidate(new Date());
		list.add(memberVO);
		return memberVO;
	}
}
