package com.edu.pnu.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.pnu.domain.MemberVO;
import com.edu.pnu.service.MemberService;

@RestController
public class MemberController {
	MemberService sv;
	public MemberController() {
		sv = new MemberService();
	}
	
	@GetMapping("/members")
	public List<MemberVO> getAllMember() {
		return sv.getAllMember();
	}
	
	@GetMapping("/member")
	public MemberVO getMemberById(Integer Id) {
		return sv.getMemberById(Id);
	}
	
	@PostMapping("/member")
	public MemberVO addMember(MemberVO memberVO) {
		return sv.addMember(memberVO);
	}
	
	@PutMapping("/member")
	public int updateMembers(MemberVO memberVO) {
		return sv.updateMembers(memberVO);
	}
	
	@DeleteMapping("/member")
	public int removeMember(Integer Id) {
		return sv.removeMember(Id);
	}
	
	@PostMapping("/memberJSON")
	public MemberVO addMemberJSON(@RequestBody MemberVO memberVO) {
		return sv.addMemberJSON(memberVO);
	}
}
