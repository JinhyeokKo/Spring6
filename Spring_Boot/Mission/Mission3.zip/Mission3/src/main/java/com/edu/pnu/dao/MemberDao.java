package com.edu.pnu.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.edu.pnu.domain.MemberVO;

public class MemberDao {
	private Connection con;
	private ResultSet rs;
	private Statement st;
	private PreparedStatement psmt;
	private MemberVO m;
	
	public MemberDao() {
		try {
			String driver = "org.h2.Driver";
			String url = "jdbc:h2:tcp://localhost/~/member";
			String username = "user";
			String password = "1234";
			
			Class.forName(driver);
			con = DriverManager.getConnection(url, username, password);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public List<MemberVO> getAllMember(){
		List<MemberVO> list = new ArrayList<>();
		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM member");
			
			while(rs.next()) {
				m = new MemberVO();
				m.setId(rs.getInt("ID"));
				m.setName(rs.getString("NAME"));
				m.setPass(rs.getString("PASS"));
				m.setRegidate(rs.getDate("REGIDATE"));
				list.add(m);
			}
		}catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(st!=null) st.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public MemberVO getMemberById(Integer Id) {
		try {
			psmt = con.prepareStatement("SELECT * FROM member WHERE ID=?");
			psmt.setInt(1, Id);
			rs = psmt.executeQuery();
			while(rs.next()) {
				m = new MemberVO();
				m.setId(rs.getInt("ID"));
				m.setName(rs.getString("NAME"));
				m.setPass(rs.getString("PASS"));
				m.setRegidate(rs.getDate("REGIDATE"));
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) rs.close();
				if(psmt!=null) psmt.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return m;
	}
	
	public MemberVO addMember(MemberVO memberVO) {
		try {
			if(getMemberById(memberVO.getId())!=null) return null;
			memberVO.setRegidate(new Date());
			memberVO.setName("name"+memberVO.getId());
			memberVO.setPass("pass"+memberVO.getId());
			psmt = con.prepareStatement("INSERT INTO member (ID,NAME,PASS) VALUES (?, ?, ?)");
			psmt.setInt(1, memberVO.getId());
			psmt.setString(2, memberVO.getName());
			psmt.setString(3, memberVO.getPass());
			psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try{
				if(psmt!=null) psmt.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return memberVO;
	}
	
	public int updateMembers(MemberVO memberVO) {
		try {
			if(getMemberById(memberVO.getId())==null) return 0;
			m.setName(memberVO.getName());
			m.setPass(memberVO.getPass());
			psmt = con.prepareStatement("UPDATE member SET NAME=?, PASS=? WHERE ID=?");
			psmt.setString(1, memberVO.getName());
			psmt.setString(2, memberVO.getPass());
			psmt.setInt(3, memberVO.getId());
			psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(psmt!=null) psmt.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return 1;
	}
	
	public int removeMember(Integer Id) {
		try {
			if(getMemberById(Id)==null) return 0;
			psmt = con.prepareStatement("DELETE FROM member WHERE ID=?");
			psmt.setInt(1, Id);
			psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(psmt!=null) psmt.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return 1;
	}
	
	public MemberVO addMemberJSON(@RequestBody MemberVO memberVO) {
		try {
			if(getMemberById(memberVO.getId())!=null) return null;
			memberVO.setRegidate(new Date());
			memberVO.setName("name"+memberVO.getId());
			memberVO.setPass("pass"+memberVO.getId());
			psmt = con.prepareStatement("INSERT INTO member (ID,NAME,PASS) VALUES (?, ?, ?)");
			psmt.setInt(1, memberVO.getId());
			psmt.setString(2, memberVO.getName());
			psmt.setString(3, memberVO.getPass());
			psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try{
				if(psmt!=null) psmt.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return memberVO;
	}
}
