package com.edu.pnu.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.edu.pnu.dao.MemberDao;
import com.edu.pnu.domain.MemberVO;

public class MemberService {
	
	MemberDao md;
	
	public MemberService() {
		md = new MemberDao();
	}
	
	public List<MemberVO> getAllMember(){
		return md.getAllMember();
	}
	
	public MemberVO getMemberById(Integer Id) {
		return md.getMemberById(Id);
	}
	
	public MemberVO addMember(MemberVO memberVO) {
		return md.addMember(memberVO);
	}
	
	public int updateMembers(MemberVO memberVO) {
		return md.updateMembers(memberVO);
	}
	
	public int removeMember(Integer Id) {
		return md.removeMember(Id);
	}
	
	public MemberVO addMemberJSON(@RequestBody MemberVO memberVO) {
		return md.addMemberJSON(memberVO);
	}
}
