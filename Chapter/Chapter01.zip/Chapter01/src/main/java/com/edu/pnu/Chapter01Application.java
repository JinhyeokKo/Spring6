package com.edu.pnu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
// 이 어노테이션 속 @ComponentScan 어노테이션이 기본적으로 main() 메소드가 포함된 해당 클래스가 속해있는 패키지를 베이스 패키지로 하여 빈 등록을 처리
// 이것은 XML 설정 파일에 <context:component-scan base-package="com.~"/>와 동일하게 동작
public class Chapter01Application {

	public static void main(String[] args) {
		SpringApplication.run(Chapter01Application.class, args);
	}

}

/* 자주 사용하는 Annotation
@RestController
@Controller
@Component
@Service
@Repository
@Configuration	@bean
*/