package com.edu.pnu.controller;

import java.util.Date;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edu.pnu.domain.BoardVO;

@RestController // REST 방식의 응답을 처리하는 컨트롤러 --> 리턴되는 문자열이 브라우저에 그대로 출력 --> 별도의 View 필요 없음
public class BoardController {

	public BoardController() {
		System.out.println("--> BoardController 생성");
	}
	
	@GetMapping("/hello") // @RequestMapping(value="/hello", method=RequestMethod.GET)과 동일한 설정
	public String hello(String name) {
		return "Hello : " + name;
	}
	
	@GetMapping("/getBoard")
	public BoardVO getBoard() {
		BoardVO board = new BoardVO();
		board.setSeq(1);
		board.setTitle("제목");
		board.setWriter("test");
		board.setContent("content");
		board.setCreateDate(new Date());
		board.setCnt(0);
		return board;
	}
}