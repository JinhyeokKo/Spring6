package com.edu.pnu.persistence;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edu.pnu.domain.Member;

public interface MemberRepository extends JpaRepository<Member, String>{

}
