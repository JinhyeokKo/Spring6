package com.edu.pnu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SecurityController {
	@GetMapping({"/", "/index"})
	public String index() {
		System.out.println("인덱스 요청");
		return "index";
	}
	
	@GetMapping("/member")
	public void member() {
		System.out.println("멤버 요청");
	}
	
	@GetMapping("/manager")
	public void manager() {
		System.out.println("매니저 요청");
	}
	
	@GetMapping("/admin")
	public void admin() {
		System.out.println("어드민 요청");
	}
	
//	@GetMapping("/loginSuccess")
//	public void loginSuccess() {
//		System.out.println("로그인성공 요청");
//	}
}
