package com.edu.pnu.domain;

public enum Role {
	ROLE_ADMIN, ROLE_MANAGER, ROLE_MEMBER
}
