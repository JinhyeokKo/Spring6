package com.edu.pnu.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig{

    @Bean
    public PasswordEncoder passwordEncoder(){
        return PasswordEncoderFactories.createDelegatingPasswordEncoder();
    }

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(security->security
                    .requestMatchers("/","/system/**").permitAll()
                    .requestMatchers("/board/**").authenticated()
                    .requestMatchers("/admin/**").hasRole("ADMIN")
                    .anyRequest().permitAll());

        http.csrf(cf->cf.disable());

        http.formLogin(form->form.loginPage("/system/login").defaultSuccessUrl("/board/getBoardList",true));

        http.exceptionHandling(ex->ex.accessDeniedPage("/system/accessDenied"));

        http.logout(logout->logout.logoutUrl("/system/logout").invalidateHttpSession(true).deleteCookies("JSESSIONID").logoutSuccessUrl("/"));

        return http.build();
    }
}
