package com.edu.pnu.controller;

public class BoardController {

}
