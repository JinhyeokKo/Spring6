package com.edu.pnu.domain;

public enum Role {
	ROLE_MEMBER, ROLE_ADMIN
}
