package com.study.boot_study.service;

import com.study.boot_study.domain.Article;
import com.study.boot_study.repository.BlogRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class BlogService {

    private final BlogRepository blogRepository;

    public Article save(Article request) {
        return blogRepository.save(request.toEntity());
    }

    public List<Article> findAll() {
        return blogRepository.findAll();
    }

    public Article findById(Long id) {
        return blogRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("해당 아이디 "+id+" 가 없습니다."));
    }

    public void delete(Long id) {
        blogRepository.deleteById(id);
    }

    @Transactional
    public Article update(Long id, Article request) {
        Article article = blogRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("해당 아이디 "+id+" 가 없습니다."));
        article.setContent(request.getContent());
        article.setTitle(request.getTitle());
        return article;
    }
}
