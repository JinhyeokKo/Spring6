package com.study.boot_study;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootStudyApplication {

    public static void main(String[] args) {
        SpringApplication.run(BootStudyApplication.class, args);
    }

}
