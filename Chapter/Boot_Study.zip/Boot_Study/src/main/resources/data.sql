INSERT INTO article (title, content) VALUES ('First Article', 'This is the first article.');
INSERT INTO article (title, content) VALUES ('Second Article', 'This is the second article.');
INSERT INTO article (title, content) VALUES ('Third Article', 'This is the third article.');